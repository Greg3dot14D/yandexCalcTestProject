DELETE FROM logging_event_property;
DELETE FROM logging_event_exception;
DELETE FROM logging_event;